//mongo DB create database(collection)
module.exports = {
    url: "mongodb+srv://pyramidd123:JqsIBB2eyt1IUgy3@cluster0.qdargx1.mongodb.net/shitalacademy"
};